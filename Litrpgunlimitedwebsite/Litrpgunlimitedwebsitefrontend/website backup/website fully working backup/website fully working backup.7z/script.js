document.addEventListener('DOMContentLoaded', () => {
    const subscriptionForm = document.getElementById('subscription-form');
    if (subscriptionForm) {
        subscriptionForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = subscriptionForm.querySelector('input[type="email"]').value;
            alert(`Subscription successful for ${email}`);
            subscriptionForm.reset();
        });
    }

    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = contactForm.querySelector('input[placeholder="Name"]').value;
            const email = contactForm.querySelector('input[placeholder="Email"]').value;
            const message = contactForm.querySelector('textarea').value;
            alert(`Message from ${name} (${email}): ${message}`);
            contactForm.reset();
        });
    }

    const newTopicForm = document.getElementById('new-topic-form');
    if (newTopicForm) {
        newTopicForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const title = newTopicForm.querySelector('input').value;
            const content = newTopicForm.querySelector('textarea').value;
            alert(`New Topic Created: ${title}\nContent: ${content}`);
            newTopicForm.reset();
        });
    }

    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = profileForm.querySelector('input[name="username"]').value;
            const characterClass = profileForm.querySelector('select[name="character-class"]').value;
            const bio = profileForm.querySelector('textarea[name="bio"]').value;
            alert(`Profile Created for ${username}!\nClass: ${characterClass}\nBio: ${bio}`);
            profileForm.reset();
        });
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = loginForm.querySelector('input[type="text"]').value;
            const password = loginForm.querySelector('input[type="password"]').value;
            alert(`Logged in as ${username}`);
            loginForm.reset();
        });
    }

    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = registerForm.querySelector('input[type="text"]').value;
            const email = registerForm.querySelector('input[type="email"]').value;
            const password = registerForm.querySelector('input[type="password"]').value;
            alert(`Registered as ${username} (${email})`);
            registerForm.reset();
        });
    }

    // Search functionality
    const searchInput = document.getElementById('search');
    const booksGrid = document.getElementById('books-grid');
    const books = booksGrid ? booksGrid.querySelectorAll('.book') : [];

    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const searchTerm = searchInput.value.toLowerCase();
            books.forEach(book => {
                const title = book.querySelector('img').alt.toLowerCase();
                book.style.display = title.includes(searchTerm) ? 'block' : 'none';
            });
        });
    }

    // Category filtering
    const categoryButtons = document.querySelectorAll('.category-btn');
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.getAttribute('data-category');
            books.forEach(book => {
                const bookCategory = book.getAttribute('data-category');
                book.style.display = category === 'all' || bookCategory === category ? 'block' : 'none';
            });
        });
    });

    // Auto play background music
    const backgroundMusic = document.getElementById('background-music');
    const playMusicButton = document.getElementById('play-music');
    if (backgroundMusic && playMusicButton) {
        playMusicButton.addEventListener('click', () => {
            backgroundMusic.play();
        });
    }

    // Swiper.js initialization
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 1,
        spaceBetween: 10,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 3,
                spaceBetween: 30,
            },
            1024: {
                slidesPerView: 4,
                spaceBetween: 40,
            },
        },
    });
});
